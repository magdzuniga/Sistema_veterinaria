package Microservicio.Registro.Controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import Microservicio.Registro.Modelo.Propietario;
import Microservicio.Registro.Service.PropietarioService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/propietarios")
public class PropietarioController {

    @Autowired
    private PropietarioService propietarioService;

    //guardar
    @PostMapping("/guardar")
    public ResponseEntity<Propietario> guardarPropietario(@RequestBody Propietario propietario) {
        // Llamamos a tu método GuardarPropietario (con 'G' mayúscula como lo tienes)
        Propietario nuevoDueño = propietarioService.GuardarPropietario(propietario);
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevoDueño); // Devuelve 201 Created
    }

    //buscar por run
    @GetMapping("/buscar/{run}")
    public ResponseEntity<Propietario> buscarPorRun(@PathVariable String run) {
        // Llamamos a tu método buscarPorRun
        Optional<Propietario> propietarioEncontrado = propietarioService.buscarPorRun(run);

        if (propietarioEncontrado.isPresent()) {
            return ResponseEntity.ok(propietarioEncontrado.get()); // Devuelve 200 OK
        } else {
            return ResponseEntity.notFound().build(); // Devuelve 404 Not Found
        }
    }

    //actualizar
    @PutMapping("/actualizar/{id}")
    public ResponseEntity<Propietario> actualizarPropietario(@PathVariable Long id, @RequestBody Propietario propietarioNuevosDatos) {
        // Llamamos al método ActualizarPropietario
        Propietario propietarioActualizado = propietarioService.ActualizarPropietario(id, propietarioNuevosDatos);

        if (propietarioActualizado != null) {
            return ResponseEntity.ok(propietarioActualizado); // Devuelve 200 OK
        } else {
            return ResponseEntity.notFound().build(); // Devuelve 404 Not Found
        }
    }

    //eliminar
    @DeleteMapping("/eliminar/{run}")
    public ResponseEntity<String> eliminarPorRun(@PathVariable String run) {
        //Llamamos al  método eliminarPropietarioporRun
        boolean fueEliminado = propietarioService.eliminarPropietarioporRun(run);

        if (fueEliminado) {
            return ResponseEntity.ok("Propietario con RUN " + run + " fue eliminado correctamente."); // Devuelve 200 OK
        } else {
            return ResponseEntity.notFound().build(); // Devuelve 404 Not Found
        }
    }
}
