package Microservicio.Registro.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import Microservicio.Registro.Modelo.Propietario;
import java.util.Optional;




@Repository
public interface PropietarioRepository extends JpaRepository<Propietario,Long> {

    //Metodo de busqueda por rut(Identificador unico)
    Optional<Propietario> findByrun(String run);

}
