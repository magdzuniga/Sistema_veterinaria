package Microservicio.Registro.Service;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import Microservicio.Registro.Modelo.Propietario;
import org.springframework.stereotype.Service;

import Microservicio.Registro.Repository.PropietarioRepository;

@Service
public class PropietarioService {

    @Autowired
    private PropietarioRepository propietarioRepository;


    //guardar
    public Propietario GuardarPropietario(Propietario propietario){
        return propietarioRepository.save(propietario);
    }

    //Buscar por rut
    public Optional<Propietario> buscarPorRun(String run){
        return propietarioRepository.findByrun(run);
    }

    //Actualizar
    public Propietario ActualizarPropietario(Long id , Propietario propietarioExistente){

        //buscamos por id primero para que sea simple
        Propietario propietarioNuevo = propietarioRepository.findById(id).orElse(null);//si tencuentra 

        //validacion
        if (propietarioNuevo !=null) {
            propietarioNuevo.setRun(propietarioExistente.getRun());
            propietarioNuevo.setNombre(propietarioExistente.getNombre());
            propietarioNuevo.setApellido(propietarioExistente.getApellido());
            propietarioNuevo.setCorreo(propietarioExistente.getCorreo());
            propietarioNuevo.setTelefono(propietarioExistente.getTelefono());
            return propietarioRepository.save(propietarioNuevo);
        }else{
            return null;
        }

    }

    //Metodo para eliminar por runn
    public boolean eliminarPropietarioporRun(String run){
        //Para ver primero si existe primero
        Propietario propietarioExistente = propietarioRepository.findByrun(run).orElse(null);

        //Validacion
        if (propietarioExistente != null) {
            propietarioRepository.delete(propietarioExistente);
            return true;
        }else{
            return false;
        }
    }
}
