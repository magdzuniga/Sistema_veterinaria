CREATE TABLE Propietario(
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    run Varchar(13)  NOT NULL UNIQUE,
    nombre Varchar(255) NOT  NULL,
    apellido Varchar(255) NOT  NULL,
    correo Varchar(255) NOT NULL,
    telefono Varchar(12) NOT NULL

);

CREATE TABLE Mascota(
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    codigo_microchip BIGINT NOT NULL UNIQUE,
    nombre Varchar(255) NOT NULL,
    especie Varchar(255)NOT NULL,
    raza Varchar(255) NOT NULL,
    edad BIGINT Not NULL,
    id_propietario BIGINT,
    CONSTRAINT fk_mascota_propietario FOREIGN KEY (id_propietario) REFERENCES Propietario(id)

);