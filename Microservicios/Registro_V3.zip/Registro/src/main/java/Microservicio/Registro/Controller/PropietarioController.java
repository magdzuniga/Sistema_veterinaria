package Microservicio.Registro.Controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import Microservicio.Registro.Modelo.Propietario;
import Microservicio.Registro.Service.PropietarioService;

//@CrossOrigin(origins = "*") // Para evitar problemas de CORS con el frontend
@RestController
@RequestMapping("/propietarios")
public class PropietarioController {

    @Autowired
    private PropietarioService propietarioService;

    //GUARDAR
    @PostMapping()
    public ResponseEntity<?> guardarPropietario(@RequestBody Propietario propietario) {
        try {
            Optional<Propietario> resultado = propietarioService.guardarPropietario(propietario);
            
            if (resultado.isPresent()) {
                return ResponseEntity.status(HttpStatus.CREATED).body(resultado.get());
            } else {
                // Si el Optional viene vacío, es porque el RUN ya existe (Regla de negocio)
                return ResponseEntity.status(HttpStatus.CONFLICT).body("El RUN ya está registrado.");
            }
        } catch (RuntimeException e) {
            // Atrapamos el error técnico que lanzamos en el Service
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    //BUSCAR POR RUN
    @GetMapping("/guardar/{run}")
    public ResponseEntity<?> buscarPorRun(@PathVariable String run) {
        try {
            Optional<Propietario> propietario = propietarioService.buscarPorRun(run);
            
            if (propietario.isPresent()) {
                return ResponseEntity.ok(propietario.get());
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Propietario no encontrado.");
            }
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    //ACTUALIZAR
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarPropietario(@PathVariable Long id, @RequestBody Propietario datos) {
        try {
            Propietario actualizado = propietarioService.actualizarPropietario(id, datos);
            
            if (actualizado != null) {
                return ResponseEntity.ok(actualizado);
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encontró el ID para actualizar.");
            }
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    //ELIMINAR
    @DeleteMapping("/eliminar/{run}")
    public ResponseEntity<?> eliminarPropietario(@PathVariable String run) {
        try {
            boolean eliminado = propietarioService.eliminarPropietarioporRun(run);
            
            if (eliminado) {
                return ResponseEntity.ok("Propietario eliminado con éxito.");
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encontró el RUN para eliminar.");
            }
        } catch (RuntimeException e) {
            // Por ejemplo, si intentas borrar un dueño que tiene mascotas y la BD lo impide
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    //Links para probar en postamn
    //1-post-http://localhost:8080/propietarios
    //2-get-run-http://localhost:8080/propietarios/buscar/
    //3-put-id-http://localhost:8080/propietarios/actualizar/
    //4-delete-run-http://localhost:8080/propietarios/actualizar/
}