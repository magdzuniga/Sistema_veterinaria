package Microservicio.Registro.Modelo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.ForeignKey;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Mascota")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Mascota {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(unique = true, length = 15 , nullable = true)
    private Long codigoMicrochip;

    @Column( nullable = false)
    private String nombre;
    @Column( nullable = false)
    private Integer edad;
    @Column(nullable = false)
    private Integer año_nacimiento;
    @Column( nullable = false)
    private String especie;
    @Column( nullable = false)
    private String raza;
   

    //Aqui viene lo medio enredado que es la vinculacion de datos con la tabla de dueño
    @ManyToOne//la relacion , pueden existir muchas mascotas para un solo dueño
    @JoinColumn(name = "id_propietario" , foreignKey = @ForeignKey(name = "fk_mascota_propietario"))
    private Propietario propietario;


}
