package Microservicio.Registro.Repository;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import Microservicio.Registro.Modelo.Mascota;



@Repository
public interface MascotaRepository extends JpaRepository<Mascota , Long> {

    Optional<Mascota> findByCodigoMicrochip(Long codigoMicrochip);
}
