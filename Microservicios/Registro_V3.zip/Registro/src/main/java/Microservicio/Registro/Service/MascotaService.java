package Microservicio.Registro.Service;

import Microservicio.Registro.Modelo.Mascota;
import Microservicio.Registro.Repository.MascotaRepository;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;//Importante para errores relacionados con la base de datos
import org.springframework.stereotype.Service;

@Service
public class MascotaService {

    @Autowired
    private MascotaRepository mascotaRepository;

    
    // Guardar
    public Optional<Mascota> GuardarMascota(Mascota mascota) {
        try {
            Optional<Mascota> existe = mascotaRepository.findByCodigoMicrochip(mascota.getCodigoMicrochip());

            if (existe.isPresent()) {
                // Usamos System.err para resaltar que hubo un conflicto 
                System.err.println("El código chip ya está registrado en la base de datos");
                return Optional.empty(); // Retornamos caja vacía
            }
            
            return Optional.of(mascotaRepository.save(mascota));

        } catch (DataAccessException e) { //maneja error relacionado con base de dato
            System.err.println("Error de base de datos al intentar guardar la mascota: " + e.getMessage());
            throw new RuntimeException("Error interno al guardar en la base de datos");
        } catch (Exception e) { //maneja errores generales
            System.err.println("Error inesperado: " + e.getMessage());
            throw new RuntimeException("Error inesperado en el servidor");
        }
    }

    // Buscar por codigo chip
    public Optional<Mascota> buscarPorChip(Long codigo_microchip) {
        try {
            return mascotaRepository.findByCodigoMicrochip(codigo_microchip);
        } catch (Exception e) {
            System.err.println("Error al buscar mascota por chip: " + e.getMessage());
            throw new RuntimeException("Error al consultar la base de datos");
        }
    }

    
    // Actualizar
    public Mascota ActualizarMascota(Long id, Mascota datosNuevos) {
        try {
            // Buscamos la mascota que ya existe en la BD
            Mascota mascotaEnBD = mascotaRepository.findById(id).orElse(null);

            // Validación
            if (mascotaEnBD != null) {
                mascotaEnBD.setCodigoMicrochip(datosNuevos.getCodigoMicrochip());
                mascotaEnBD.setNombre(datosNuevos.getNombre());
                mascotaEnBD.setEspecie(datosNuevos.getEspecie());
                mascotaEnBD.setRaza(datosNuevos.getRaza());
                mascotaEnBD.setEdad(datosNuevos.getEdad());
                
                // No se actualizan claves foraneas como el id del propietario

                return mascotaRepository.save(mascotaEnBD);
            } else {
                return null;
            }
        } catch (DataAccessException e) {
            System.err.println("Error de base de datos al actualizar: " + e.getMessage());
            throw new RuntimeException("Error interno al actualizar los datos");
        }
    }

    
    // Eliminar por codigo chip
    public boolean eliminarMascotaExistente(Long codigo_microchip) {
        try {
            Optional<Mascota> mascota = mascotaRepository.findByCodigoMicrochip(codigo_microchip);

            if (mascota.isPresent()) {
                mascotaRepository.delete(mascota.get());
                return true;
            }
            return false;
            
        } catch (DataAccessException e) {
            System.err.println("Error al intentar eliminar la mascota en la BD: " + e.getMessage());
            throw new RuntimeException("No se puede eliminar la mascota por un problema en la base de datos");
        }
    }
}