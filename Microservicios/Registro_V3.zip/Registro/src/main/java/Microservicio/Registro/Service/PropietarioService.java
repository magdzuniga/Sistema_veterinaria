package Microservicio.Registro.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;//Importante para errores relacionados con la base de datos
import org.springframework.stereotype.Service;

import Microservicio.Registro.Modelo.Propietario;
import Microservicio.Registro.Repository.PropietarioRepository;

@Service
public class PropietarioService {

    @Autowired
    private PropietarioRepository propietarioRepository;

    // Guardar
    public Optional<Propietario> guardarPropietario(Propietario propietario) {
        try {
            Optional<Propietario> existe = propietarioRepository.findByrun(propietario.getRun());
            
            if (existe.isPresent()) { 
                return Optional.empty();//si es que ya existe no hace nada
            }
            
            // Intentamos guardar
            return Optional.of(propietarioRepository.save(propietario));//si no existe lo guarda

        } catch (DataAccessException e) {
            //Los DataAccessExeption son manejos de errores relacionados con la base de datos
            System.err.println("Error de base de datos al intentar guardar el propietario: " + e.getMessage());//por lo que vi e.getMessage es donde te dice directamente que fallo
            // Por lo que vi esto es como un boton de panico para el controller donde detecta altiro que algo salio mal y bloquea el codigo hasta aqui mostrando el mensaje
            throw new RuntimeException("Error interno al guardar en la base de datos");
        } catch (Exception e) {
            //En caso de tener cualquier otro error
            System.err.println("Error inesperado: " + e.getMessage());
            throw new RuntimeException("Error inesperado en el servidor");
        }
    }

    // Buscar por rut
    public Optional<Propietario> buscarPorRun(String run) {
        try {
            return propietarioRepository.findByrun(run);
        } catch (Exception e) {
            System.err.println("Error al buscar propietario por RUN: " + e.getMessage());
            throw new RuntimeException("Error al consultar la base de datos");
        }
    }

    // Actualizar
    public Propietario actualizarPropietario(Long id, Propietario datosNuevos) {
        try {
            Propietario propietarioEnBD = propietarioRepository.findById(id).orElse(null);

            if (propietarioEnBD != null) {
                propietarioEnBD.setRun(datosNuevos.getRun());
                propietarioEnBD.setNombre(datosNuevos.getNombre());
                propietarioEnBD.setApellido(datosNuevos.getApellido());
                propietarioEnBD.setCorreo(datosNuevos.getCorreo());
                propietarioEnBD.setTelefono(datosNuevos.getTelefono());
                
                return propietarioRepository.save(propietarioEnBD);
            } else {
                return null; // No lo encontró
            }
        } catch (DataAccessException e) {
            System.err.println("Error de base de datos al actualizar: " + e.getMessage());
            throw new RuntimeException("Error interno al actualizar los datos");
        }
    }

    // Eliminar por run
    public boolean eliminarPropietarioporRun(String run) {

        try {
            //busca si el propietario existe
            Propietario propietarioExistente = propietarioRepository.findByrun(run).orElse(null);

            if (propietarioExistente != null) {
                //si existe lo elimina y retorna true
                propietarioRepository.delete(propietarioExistente);
                return true;
            } else {
                //no lo encuentra por lo que no lo borra
                return false;
            }
        } catch (DataAccessException e) {
            System.err.println("Error al intentar eliminar propietario en la BD: " + e.getMessage());
            throw new RuntimeException("No se puede eliminar el propietario porque está en uso o la BD falló");
        }
    }
}