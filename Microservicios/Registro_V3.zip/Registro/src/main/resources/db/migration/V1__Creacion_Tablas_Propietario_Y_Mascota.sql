CREATE TABLE propietario (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    run VARCHAR(13) UNIQUE NOT NULL,
    nombre VARCHAR(255) NOT NULL,
    apellido VARCHAR(255) NOT NULL,
    correo VARCHAR(255) NOT NULL,
    telefono VARCHAR(12) NOT NULL
);

CREATE TABLE mascota (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    codigo_microchip BIGINT UNIQUE,
    nombre VARCHAR(255) NOT NULL,
    edad INT NOT NULL,
    año_nacimiento INT NOT NULL,
    especie VARCHAR(255) NOT NULL,
    raza VARCHAR(255) NOT NULL,
    id_propietario BIGINT,
    CONSTRAINT fk_mascota_propietario FOREIGN KEY (id_propietario) REFERENCES propietario(id)
);