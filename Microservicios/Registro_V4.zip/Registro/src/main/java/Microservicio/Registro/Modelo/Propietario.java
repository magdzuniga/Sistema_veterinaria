package Microservicio.Registro.Modelo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity //Entity tratara a esta clase como un tabla de base de datos
@Table(name = "Propietario")//nombre de la tabla
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Propietario {

    @Id
    @Column(length = 13 , nullable = false)//Column , es una columna de la tabla , unique es para un dato unico en la tabla 
    private String runPropietario; //length es para el rango de escritura

    @Column(nullable = false)
    private String nombre;

    @Column( nullable = false)
    private String apellido;

    @Column( nullable = false)
    private String correo;

    @Column(length = 12 , nullable = false)
    private String telefono;

}
