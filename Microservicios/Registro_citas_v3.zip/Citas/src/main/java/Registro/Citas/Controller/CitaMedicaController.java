package Registro.Citas.Controller;

import Registro.Citas.Modelo.CitaMedicaDTO;
import Registro.Citas.Modelo.CitaMedica;
import Registro.Citas.Service.CitaMedicaService;
import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/v1/citas")
public class CitaMedicaController {

    @Autowired
    private CitaMedicaService citaMedicaService;

    // 1. Guardar una nueva cita en la base de datos local
    @PostMapping("/guardar")
    public ResponseEntity<?> guardarCita(@Valid @RequestBody CitaMedica citaMedica) {
        try {
            Optional<CitaMedica> nuevaCita = citaMedicaService.guardarCitaMedica(citaMedica);
            
            if (nuevaCita.isPresent()) {
                return ResponseEntity.status(HttpStatus.CREATED).body(nuevaCita.get());
            } else {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body("Ya existe una cita registrada con ese código de consulta.");
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al guardar la cita: " + e.getMessage());
        }
    }

    // 2. Buscar la cita completa (con mascota, propietario y empleado desde los otros microservicios)
    @GetMapping("/detalle/{codigoConsulta}")
    public ResponseEntity<?> obtenerDetalleCita(@PathVariable String codigoConsulta) {
        try {
            Optional<CitaMedicaDTO> citaCompleta = citaMedicaService.obtenerDetalleCompletoCita(codigoConsulta);

            if (citaCompleta.isPresent()) {
                return ResponseEntity.ok(citaCompleta.get());
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("No se encontró ninguna cita con el código: " + codigoConsulta);
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al obtener los detalles de la cita: " + e.getMessage());
        }
    }
}