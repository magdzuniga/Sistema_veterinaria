package Registro.Citas.Modelo;

import java.time.LocalDateTime;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//Esto va a base de datos

@Entity
@Table(name = "citas_medicas")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CitaMedica {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true , nullable = false ) 
    private String codigoConsulta;

    @Column(nullable = false)
    private LocalDateTime fechaHora;//al ser una cita es para manejar fecha y hora de la cita

    @Column(nullable = false)
    private String motivo;
    @Column(nullable = false)
    private String estado;

    @Column(length = 500 , nullable = true)
    private String observaciones;

   @Column(nullable = false)
    private String codigoMicrochip; 

    @Column(nullable = false)
    private String runPropietario; 

    @Column(nullable = false)
    private String runEmpleado; 
}
