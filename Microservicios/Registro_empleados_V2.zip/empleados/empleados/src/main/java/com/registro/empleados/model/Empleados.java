package com.registro.empleados.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;

import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="empleados")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Empleados {
    
   
    @Id
    @Column(length = 13 , nullable = false)
    private String runEmpleado;
    
    @Column(nullable = false)
    private String nombre;
    
    @Column(nullable = false)
    private LocalDate fecha_nacimiento;
    
    @Column(nullable = false)
    private String cargo;
    
    @Column(nullable = false)
    private String gmail;
    
    @Column(length = 12 , nullable = false)
    private String numero_telefono;
}
