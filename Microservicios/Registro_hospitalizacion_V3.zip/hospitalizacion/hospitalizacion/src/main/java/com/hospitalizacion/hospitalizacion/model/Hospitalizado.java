package com.hospitalizacion.hospitalizacion.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;

import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name = "hospitalizados")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Hospitalizado {

   
    @Id
    @Column(length = 15 ,nullable = false ) 
    private String codigoHospitalizacion;

    @Column( length = 100, nullable = false)
    private String sala;

    @Column( nullable = false)
    private LocalDateTime horaMonitoreo;

    @Column(length = 255 ,nullable = false)
    private String descripcion;

    @Column(length = 15 ,nullable = false)
    private String codigoMicrochip; 

}
