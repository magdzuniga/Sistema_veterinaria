CREATE TABLE historial (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    mascota_id BIGINT NOT NULL UNIQUE,
    fecha_creacion DATETIME NOT NULL
);

CREATE TABLE consultas (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    fecha DATETIME NOT NULL,
    motivo VARCHAR(255),
    peso DOUBLE,
    temperatura DOUBLE,
    notas_medicas TEXT,
    historial_id BIGINT NOT NULL,
    CONSTRAINT fk_consultas_historial FOREIGN KEY (historial_id) REFERENCES historial(id) ON DELETE CASCADE
);