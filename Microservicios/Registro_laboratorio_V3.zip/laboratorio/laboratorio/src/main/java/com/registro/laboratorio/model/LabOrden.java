package com.registro.laboratorio.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//esto sera directo para la base de datos
@Entity
@Table(name = "Lab_orden")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LabOrden {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String nombreOrden;

    @Column(nullable = false)
    private LocalDateTime fechaPedido;

    @Column(length =  255,nullable = false)
    private String tipoExamen;

    @Column(length =  255,nullable = false)
    private String estado;
    
    @Column(length =  255, nullable =  false)
    private String descripcion;

    @Column(nullable = false)
    private String codigoMicrochip; 





}
