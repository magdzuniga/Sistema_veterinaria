package Registro.Citas.Client;

public interface EmpleadoClient {

}
