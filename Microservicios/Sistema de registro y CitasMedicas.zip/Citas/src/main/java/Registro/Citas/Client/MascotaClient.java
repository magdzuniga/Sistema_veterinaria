package Registro.Citas.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import Registro.Citas.Modelo.MascotaDTO;


@FeignClient(name = "microservicio-registro-mascota" , url = "http://localhost:8080")
public interface MascotaClient {

    @GetMapping("/mascotas/buscar/{codigoMicrochip}")
    MascotaDTO obtenerMascota(@PathVariable("codigoMicrochip") Long codigoMicrochip);

}
