package Registro.Citas.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import Registro.Citas.Modelo.PropietarioDTO;

@FeignClient(name = "microservicio-registro-propietario" , url = "http://localhost:8080")
public interface PropietarioClient {

    @GetMapping("/guardar/{run}")
    PropietarioDTO obtenerPropietarioporRun(@PathVariable("run") String run);
}
