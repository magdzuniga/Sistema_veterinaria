package Registro.Citas.Controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import Registro.Citas.Modelo.CitaMedica;
import Registro.Citas.Modelo.EmpleadosDTO;
import Registro.Citas.Modelo.MascotaDTO;
import Registro.Citas.Modelo.PropietarioDTO;
import Registro.Citas.Service.CitaMedicaService;

@RestController
@RequestMapping("/api/citas")
public class CitaMedicaController {

    @Autowired
    private CitaMedicaService citaMedicaService;

    // Endpoint para guardar una nueva cita médica
    @PostMapping("/guardar")
    public ResponseEntity<?> guardarCita(@RequestBody CitaMedica citaMedica) {
        try {
            Optional<CitaMedica> citaGuardada = citaMedicaService.guardarCitaMedica(citaMedica);
            if (citaGuardada.isPresent()) {
                return ResponseEntity.status(HttpStatus.CREATED).body(citaGuardada.get());
            } else {
                return ResponseEntity.status(HttpStatus.CONFLICT).body("Ya existe una cita con ese código");
            }
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    // Endpoint para buscar cita por código de consulta
    @GetMapping("/buscar/{codigoConsulta}")
    public ResponseEntity<?> buscarCita(@PathVariable String codigoConsulta) {
        try {
            Optional<CitaMedica> cita = citaMedicaService.buscarPorCodigoConsulta(codigoConsulta);
            if (cita.isPresent()) {
                return ResponseEntity.ok(cita.get());
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Cita no encontrada");
            }
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }

    // Endpoint para obtener datos de mascota por código de microchip
    @GetMapping("/mascota/{codigoMicrochip}")
    public ResponseEntity<?> obtenerMascota(@PathVariable Long codigoMicrochip) {
        Optional<MascotaDTO> mascota = citaMedicaService.obtenerMascota(codigoMicrochip);
        if (mascota.isPresent()) {
            return ResponseEntity.ok(mascota.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Mascota no encontrada");
        }
    }

    // Endpoint para obtener datos de propietario por RUN
    @GetMapping("/propietario/{run}")
    public ResponseEntity<?> obtenerPropietario(@PathVariable String run) {
        Optional<PropietarioDTO> propietario = citaMedicaService.obtenerPropietario(run);
        if (propietario.isPresent()) {
            return ResponseEntity.ok(propietario.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Propietario no encontrado");
        }
    }

    // Endpoint para obtener datos de empleado por RUN
    @GetMapping("/empleado/{run}")
    public ResponseEntity<?> obtenerEmpleado(@PathVariable String run) {
        Optional<EmpleadosDTO> empleado = citaMedicaService.obtenerEmpleado(run);
        if (empleado.isPresent()) {
            return ResponseEntity.ok(empleado.get());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Empleado no encontrado");
        }
    }
}