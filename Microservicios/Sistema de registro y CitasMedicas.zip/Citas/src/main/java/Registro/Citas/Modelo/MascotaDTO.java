package Registro.Citas.Modelo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MascotaDTO {
    private Long id;
    private String nombre;
    private Integer edad;
    private String especie;
    private String raza;
}
