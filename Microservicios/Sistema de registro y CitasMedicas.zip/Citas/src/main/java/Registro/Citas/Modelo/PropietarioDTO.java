package Registro.Citas.Modelo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PropietarioDTO {
    private Long id;
    private String nombre;
    private String apellido;
    private String telefono;
    private String correo;
}
