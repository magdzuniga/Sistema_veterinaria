package Registro.Citas.Service;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

import Registro.Citas.Modelo.CitaMedica;
import Registro.Citas.Repository.CitaMedicaRepository;

//importamos los clientes de donde tenemos el metodo para traer los datos
import Registro.Citas.Client.PropietarioClient;
import Registro.Citas.Client.MascotaClient;
import Registro.Citas.Client.EmpleadoClient;

@Service
public class CitaMedicaService {

    @Autowired
    private CitaMedicaRepository citaMedicaRepository;

    @Autowired
    private PropietarioClient propietarioClient;

    @Autowired
    private MascotaClient mascotaClient;
    @Autowired
    private EmpleadoClient empleadoClient;

    //guardar la cita
    public Optional<CitaMedica> guardarCitaMedica(CitaMedica citaMedica){
        try{
            Optional<CitaMedica> existe = citaMedicaRepository.findByCodigoConsulta(citaMedica.getCodigoConsulta());

            if(existe.isPresent()){
                return Optional.empty();
            }

            return Optional.of(citaMedicaRepository.save(citaMedica));

        } catch (DataAccessException e){
            System.err.println("Error de base de datos al intentar registrar la cita " + e.getMessage());
            throw new RuntimeException("Error interno al guardar en la base de datos");
        } catch(Exception e){
            System.err.println("Error inesperado" + e.getMessage());
            throw new RuntimeException("Error inesperado en el servidor");
        }
    }

    //Buscar por codigoConsulta
    public Optional<CitaMedica> buscarPorCodigoConsulta(String codigoConsulta){
        try{
            return citaMedicaRepository.findByCodigoConsulta(codigoConsulta);
        }catch(Exception e){
            System.err.println("Error al buscar el codigo de la cita medica " + e.getMessage());
            throw new RuntimeException("Error al consultar la base de datos");
        }
    }

    //Aqui para abajo traemos los datos que necesitamos

    public Optional<MascotaDTO> obtenerMascota(Long codigoMicrochip) {
        try {
            MascotaDTO mascota = mascotaClient.obtenerMascota(codigoMicrochip);
            return Optional.ofNullable(mascota);
        } catch (Exception e) {
            System.err.println("Error al obtener mascota: " + e.getMessage());
            return Optional.empty();
        }
    }

    public Optional<PropietarioDTO> obtenerPropietario(String run) {
        try {
            PropietarioDTO propietario = propietarioClient.obtenerPropietarioporRun(run);
            return Optional.ofNullable(propietario);
        } catch (Exception e) {
            System.err.println("Error al obtener propietario: " + e.getMessage());
            return Optional.empty();
        }
    }

    public Optional<EmpleadosDTO> obtenerEmpleado(String run) {
        try {
            EmpleadosDTO empleado = empleadoClient.obtenerEmpleado(run);
            return Optional.ofNullable(empleado);
        } catch (Exception e) {
            System.err.println("Error al obtener empleado: " + e.getMessage());
            return Optional.empty();
        }
    }
}
}
