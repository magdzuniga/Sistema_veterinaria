package com.registro.empleados.service;

import java.util.Optional;
import com.registro.empleados.model.Empleados;
import com.registro.empleados.repository.EmpleadosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;


@Service
public class EmpleadosService {
    @Autowired
    private EmpleadosRepository empleadosRepository;

    //Guardar
    public Optional<Empleados> guardarEmpleado(Empleados empleados){
        try{
            Optional<Empleados> existe = empleadosRepository.findByRun(empleados.getRun());

            if(existe.isPresent()){
                return Optional.empty();
            }

            return Optional.of(empleadosRepository.save(empleados));
        }catch(DataAccessException e){
            System.err.println("Error de base de datos al intentar registrar el empleado" + e.getMessage());
            throw new RuntimeException("Error interno al guardar en la base de datos");
        }catch(Exception e){
            System.err.println("Error inesperado :" + e.getMessage());
            throw new RuntimeException("Error inesperado en el servidor");
        }
    }

    //Buscar por rut
    public Optional<Empleados> buscarPorRun(String run){
        try{
            return empleadosRepository.findByRun(run);
        }catch(Exception e){
            System.err.println("Error al buscar empleado por run: " + e.getMessage());
            throw new RuntimeException("Error al consultar la base de datos");
        }
    }

    //Actualizar
    public Empleados ActualizarEmpleados(String run , Empleados empleadosExistentes){

        try{
            //buscamos por id primero para que sea simple
            Empleados empleadosNuevo = empleadosRepository.findByRun(run).orElse(null);//si tencuentra 

            //validacion
            if (empleadosNuevo !=null) {
            empleadosNuevo.setNombre(empleadosExistentes.getNombre());
            empleadosNuevo.setRun(empleadosExistentes.getRun());
            empleadosNuevo.setFecha_nacimiento(empleadosExistentes.getFecha_nacimiento());
            empleadosNuevo.setCargo(empleadosExistentes.getCargo());
            empleadosNuevo.setGmail(empleadosExistentes.getGmail());
            empleadosNuevo.setNumero_telefono(empleadosExistentes.getNumero_telefono());
            return empleadosRepository.save(empleadosNuevo);
            }else{
            return null;
            }
        }catch(DataAccessException e){
            System.err.println("Error en la base de datos al acutualizar : " + e.getMessage());
            throw new RuntimeException("Error interno al actualizar los datos");
        }

    }


    //Metodo para eliminar por runn
    public boolean eliminarEmpleadosRun(String run){
        try{
            //Para ver primero si existe primero
            Empleados empleadosExistentes = empleadosRepository.findByRun(run).orElse(null);

            //Validacion
            if (empleadosExistentes != null) {
                empleadosRepository.delete(empleadosExistentes);
                return true;
            }else{
                return false;
            }
        }catch(DataAccessException e){
            System.err.println("Error al intentar eliminar propietario en la Base de datos: " + e.getMessage());
            throw new RuntimeException("No se puede elimar el propietario porquie esta en uso la base de datos fallo");
        }
    }

}
