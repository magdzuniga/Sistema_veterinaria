package com.example.Tratamiento.Controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Tratamiento.Model.Tratamiento;
import com.example.Tratamiento.Service.TratamientoService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/tratamientos")
public class TratamientoController {

    private final TratamientoService service;

    public TratamientoController(TratamientoService service) {
        this.service = service;
    }

    @PostMapping("/revisar")
    public ResponseEntity<Tratamiento> agregarRevision(@Valid @RequestBody Tratamiento tratamiento) {
        Tratamiento nuevoTratamiento = service.registrarRevision(tratamiento);
        return new ResponseEntity<>(nuevoTratamiento, HttpStatus.CREATED);
    }

    @GetMapping("/historial/{mascotaId}")
    public ResponseEntity<List<Tratamiento>> verHistorial(@PathVariable Long mascotaId) {
        List<Tratamiento> historial = service.obtenerHistorialPorMascota(mascotaId);
        
        if (historial.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        
        return ResponseEntity.ok(historial);
    }
}