package com.example.Tratamiento.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Tratamiento.Model.Tratamiento;
import com.example.Tratamiento.Repository.TratamientoRepository;

@RestController
@RequestMapping("/api/tratamientos")
public class TratamientoController {

    @Autowired
    private TratamientoRepository repository;

    // Endpoint para agregar una revisión al historial
    @PostMapping("/revisar")
    public Tratamiento agregarRevision(@RequestBody Tratamiento tratamiento) {
        return repository.save(tratamiento);
    }

    // Endpoint para ver el historial de una mascota
    @GetMapping("/historial/{mascotaId}")
    public List<Tratamiento> verHistorial(@PathVariable Long mascotaId) {
        return repository.findByMascotaId(mascotaId);
    }
}