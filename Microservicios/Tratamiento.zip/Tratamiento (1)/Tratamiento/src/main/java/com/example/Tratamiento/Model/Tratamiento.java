package com.example.Tratamiento.Model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "tratamientos")
@Data
@AllArgsConstructor
@NoArgsConstructor 
public class Tratamiento {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private Long mascotaId; // Relación con la mascota
    @Column(nullable = false)
    private String diagnostico;
    @Column(nullable = false)
    private String medicacion;
    @Column(nullable = false)
    private String observaciones;
    @Column(nullable = false)
    private LocalDateTime fechaRevision = LocalDateTime.now();
}