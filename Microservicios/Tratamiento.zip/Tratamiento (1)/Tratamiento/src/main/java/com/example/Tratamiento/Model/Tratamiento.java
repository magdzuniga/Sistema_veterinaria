package com.example.Tratamiento.Model;

import java.time.LocalDateTime;
// Importa la clase LocalDateTime de Java para poder manejar fechas y horas exactas (año, mes, día, hora, minuto, segundo)

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "tratamientos")
@Data
@AllArgsConstructor
@NoArgsConstructor 
public class Tratamiento {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotNull(message = "El ID de la mascota es obligatorio.")
    @Column(nullable = false)
    private Long mascotaId; 

    @NotBlank(message = "El diagnóstico no puede estar vacío.")
    @Size(max = 255, message = "El diagnóstico no puede superar los 255 caracteres.")
    @Column(nullable = false)
    private String diagnostico;

    @Column(name = "tratamiento_prescrito", columnDefinition = "TEXT") 
    private String medicacion;

    @Column(columnDefinition = "TEXT")
    private String observaciones;

    @Column(name = "fecha_revision", nullable = false, insertable = false, updatable = false)
    private LocalDateTime fechaRevision;
}