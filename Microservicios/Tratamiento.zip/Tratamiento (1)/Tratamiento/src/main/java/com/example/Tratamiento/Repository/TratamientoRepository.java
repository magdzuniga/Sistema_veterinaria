package com.example.Tratamiento.Repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.Tratamiento.Model.Tratamiento;
import org.springframework.stereotype.Repository; // Buena práctica agregar esta anotación

@Repository
public interface TratamientoRepository extends JpaRepository<Tratamiento, Long> {
    
    // El Spring crea el SQL por mi
    List<Tratamiento> findByMascotaId(Long mascotaId);
    
}