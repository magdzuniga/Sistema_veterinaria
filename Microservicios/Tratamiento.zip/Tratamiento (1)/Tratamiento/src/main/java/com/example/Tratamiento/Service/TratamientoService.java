package com.example.Tratamiento.Service;

import org.springframework.stereotype.Service;
import com.example.Tratamiento.Model.Tratamiento;
import com.example.Tratamiento.Repository.TratamientoRepository;

import java.util.List;
import java.util.Optional;

@Service
public class TratamientoService {

    private final TratamientoRepository repository;

    public TratamientoService(TratamientoRepository repository) {
        this.repository = repository;
    }

    public Tratamiento registrarRevision(Tratamiento tratamiento) {
        return repository.save(tratamiento);
    }

    public List<Tratamiento> obtenerHistorialPorMascota(Long mascotaId) {
        return repository.findByMascotaId(mascotaId);
    }

    public Optional<Tratamiento> obtenerRevisionPorId(Long id) {
        return repository.findById(id);
    }
}