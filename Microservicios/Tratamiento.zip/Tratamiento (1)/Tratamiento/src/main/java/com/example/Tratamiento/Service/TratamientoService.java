package com.example.Tratamiento.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Tratamiento.Model.Tratamiento;
import com.example.Tratamiento.Repository.TratamientoRepository;

import java.util.List;
import java.util.Optional;

@Service
public class TratamientoService {

    @Autowired
    private TratamientoRepository repository;

    /**
     * Crea una nueva revisión y la añade al historial de la mascota.
     */
    public Tratamiento registrarRevision(Tratamiento tratamiento) {
        // Aquí podrías añadir lógica extra, por ejemplo:
        // Validar si la mascota existe llamando a otro microservicio.
        
        return repository.save(tratamiento);
    }

    /**
     * Recupera todas las revisiones de una mascota específica.
     */
    public List<Tratamiento> obtenerHistorialPorMascota(Long mascotaId) {
        return repository.findByMascotaId(mascotaId);
    }

    /**
     * Busca una revisión específica por su ID.
     */
    public Optional<Tratamiento> obtenerRevisionPorId(Long id) {
        return repository.findById(id);
    }
}