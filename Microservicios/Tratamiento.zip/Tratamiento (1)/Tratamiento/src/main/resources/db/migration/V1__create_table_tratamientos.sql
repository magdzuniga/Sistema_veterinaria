CREATE TABLE tratamientos (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    mascota_id BIGINT NOT NULL,
    diagnostico VARCHAR(255) NOT NULL,
    tratamiento_prescrito TEXT,
    observaciones TEXT,
    fecha_revision TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);