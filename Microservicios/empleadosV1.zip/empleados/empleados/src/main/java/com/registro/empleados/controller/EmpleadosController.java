package com.registro.empleados.controller;

import com.registro.empleados.model.Empleados; // O Empleado si lo cambiaste a singular
import com.registro.empleados.service.EmpleadosService;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/registro/empleados")
public class EmpleadosController {
    
    @Autowired
    private EmpleadosService empleadosService;

    // CREAR: POST a /api/v1/registro/empleados
    @PostMapping
    public ResponseEntity<Empleados> guardarEmpleado(@RequestBody Empleados empleados) {
        Empleados nuevoEmpleado = empleadosService.GuardarEmpleados(empleados);
        
        // Validación: Si el service devolvió null, el RUN ya estaba registrado
        if (nuevoEmpleado == null) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build(); // Devuelve 409 Conflict
        }
        
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevoEmpleado); // Devuelve 201 Created
    }

    // LEER: GET a /api/v1/registro/empleados/{run}
    @GetMapping("/{run}")
    public ResponseEntity<Empleados> buscarPorRun(@PathVariable String run) {
        Optional<Empleados> empleadoEncontrado = empleadosService.buscarPorRun(run);

        if (empleadoEncontrado.isPresent()) {
            return ResponseEntity.ok(empleadoEncontrado.get()); // Devuelve 200 OK
        } else {
            return ResponseEntity.notFound().build(); // Devuelve 404 Not Found
        }
    }

    // ACTUALIZAR: PUT a /api/v1/registro/empleados/{run}
    @PutMapping("/{run}")
    public ResponseEntity<Empleados> actualizarEmpleado(@PathVariable String run, @RequestBody Empleados empleadosNuevosDatos) {
        Empleados empleadoActualizado = empleadosService.ActualizarEmpleados(run, empleadosNuevosDatos);

        if (empleadoActualizado != null) {
            return ResponseEntity.ok(empleadoActualizado); // Devuelve 200 OK
        } else {
            return ResponseEntity.notFound().build(); // Devuelve 404 Not Found
        }
    }

    // ELIMINAR: DELETE a /api/v1/registro/empleados/{run}
    @DeleteMapping("/{run}")
    public ResponseEntity<String> eliminarPorRun(@PathVariable String run) {
        boolean fueEliminado = empleadosService.eliminarEmpleadosRun(run);

        if (fueEliminado) {
            return ResponseEntity.ok("Empleado con RUN " + run + " fue eliminado correctamente."); // Devuelve 200 OK
        } else {
            return ResponseEntity.notFound().build(); // Devuelve 404 Not Found
        }
    }
}
