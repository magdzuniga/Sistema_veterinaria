package com.registro.empleados.service;

import java.util.Optional;
import com.registro.empleados.model.Empleados;
import com.registro.empleados.repository.EmpleadosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class EmpleadosService {
    @Autowired
    private EmpleadosRepository empleadosRepository;

    public Empleados GuardarEmpleados(Empleados empleados){
        return empleadosRepository.save(empleados);
    }

    //Buscar por rut
    public Optional<Empleados> buscarPorRun(String run){
        return empleadosRepository.findByRun(run);
    }

    //Actualizar
    public Empleados ActualizarEmpleados(String run , Empleados empleadosExistentes){

        //buscamos por id primero para que sea simple
        Empleados empleadosNuevo = empleadosRepository.findByRun(run).orElse(null);//si tencuentra 

        //validacion
        if (empleadosNuevo !=null) {
            empleadosNuevo.setNombre(empleadosExistentes.getNombre());
            empleadosNuevo.setRun(empleadosExistentes.getRun());
            empleadosNuevo.setFecha_nacimiento(empleadosExistentes.getFecha_nacimiento());
            empleadosNuevo.setCargo(empleadosExistentes.getCargo());
            empleadosNuevo.setGmail(empleadosExistentes.getGmail());
            empleadosNuevo.setNumero_telefono(empleadosExistentes.getNumero_telefono());
            return empleadosRepository.save(empleadosNuevo);
        }else{
            return null;
        }

    }


    //Metodo para eliminar por runn
    public boolean eliminarEmpleadosRun(String run){
        //Para ver primero si existe primero
        Empleados empleadosExistentes = empleadosRepository.findByRun(run).orElse(null);

        //Validacion
        if (empleadosExistentes != null) {
            empleadosRepository.delete(empleadosExistentes);
            return true;
        }else{
            return false;
        }
    }

}
