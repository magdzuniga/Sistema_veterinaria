
CREATE TABLE empleados(
    id BiGINT AUTO_INCREMENT PRIMARY KEY,
    run Varchar(13)  NOT NULL UNIQUE,
    nombre VARCHAR(255) NOT NULL,
    fecha_nacimiento DATE,
    cargo VARCHAR(255)  NOT NULL,
    gmail VARCHAR(100) NOT NULL,
    numero_telefono VARCHAR(12) 


);