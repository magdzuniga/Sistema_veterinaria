package com.pagos.facturacion.Model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Factura")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Factura {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 255, nullable = false)
    private String codigoFactura;
    
    @Column(length = 255, nullable = false)
    private String detalles;

    @Column(name = "fecha_emision",nullable = false)
    private LocalDateTime fechaEmision;

    
    @Column(nullable = false)
    private BigDecimal precio;

    


    // run del propietario 
    @Column(length =  13, nullable = false)
    private String runPropietario;

}
