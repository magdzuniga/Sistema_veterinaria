package com.hospitalizacion.hospitalizacion.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import com.hospitalizacion.hospitalizacion.model.*;
import com.hospitalizacion.hospitalizacion.repository.HospitalizadoRepository;

import feign.FeignException;

import com.hospitalizacion.hospitalizacion.client.*;

@Service
public class HospitalizadoService {

    @Autowired
    private HospitalizadoRepository hospitalizadoRepository;

    @Autowired 
    private MascotaClient mascotaClient;

    //guardar la cita
    public Optional<Hospitalizado> guardarHospitalizacion(Hospitalizado hospitalizado) {
    
    //Validar si el ya existe una hospitalizacion con ese codigo
        Optional<Hospitalizado> existe = hospitalizadoRepository.findByCodigoHospitalizacion(hospitalizado.getCodigo_hospitalizacion());
        if(existe.isPresent()){
            // Lanzamos una excepción personalizada en lugar de Optional.empty()
            throw new RuntimeException("Ya existe una Hospitalizado con el código: " + hospitalizado.getCodigo_hospitalizacion());
        }

    //Validar con los otros microservicios

    //validar a la mascota
        try{
            //llamamos al microservicio de mascota
            mascotaClient.obtenerMascotaporCodigo(hospitalizado.getCodigo_microchip());
        } catch (FeignException.NotFound e){
            throw new RuntimeException("Error: La mascota con el codigo " + hospitalizado.getCodigo_microchip() + " no existe o no se encontrado");
        }

        //Si pasó todas las validaciones, guardamos en la base de datos
        try {
            return Optional.of(hospitalizadoRepository.save(hospitalizado));
        } catch (DataAccessException e) {
            System.err.println("Error de base de datos al intentar registrar la hospitalizacion: " + e.getMessage());
            throw new RuntimeException("Error interno al guardar en la base de datos");
        } catch(Exception e) {
            System.err.println("Error inesperado: " + e.getMessage());
            throw new RuntimeException("Error inesperado en el servidor");
        }
    }

    //Buscar por codigoConsulta
    public Optional<Hospitalizado> buscarPorCodigoHospitalizacion(String codigo_hospitalizacion){
        try{
            return hospitalizadoRepository.findByCodigoHospitalizacion(codigo_hospitalizacion);
        }catch(Exception e){
            System.err.println("Error al buscar el codigo de la Hospitalizacion " + e.getMessage());
            throw new RuntimeException("Error al consultar la base de datos");
        }
    }

    //la mejor forma de definirlo es que , esta parte es la api hacia los otros microservicios , es como un puente de datos seguros
    public Optional<MascotaDTO> obtenerMascota(Long codigo_microchip){
        try {
            MascotaDTO mascota = mascotaClient.obtenerMascotaporCodigo(codigo_microchip);
            return Optional.ofNullable(mascota);
        } catch (Exception e) {
            System.err.println("Error al obtener datos de la mascota " + e.getMessage());
            return Optional.empty();
        }
    }

    public Optional<HospitalizadoDTO> obtenerDetalleCompletoHospitalizacion(String codigo_hospitalizacion) {
        try {
            //Aqui buscamos la consulta que se guarda premiamente en base de datos
            Optional<Hospitalizado> existe = buscarPorCodigoHospitalizacion(codigo_hospitalizacion);
            
            //si no la encuentra se detiene y no devuelve nada 
            if (existe.isEmpty()) {
                return Optional.empty(); 
            }
            
            //si la encuentra saca la informacion desde existe
            Hospitalizado hospitalizado = existe.get();
            //y despues la guarda en DetalleCompleto
            HospitalizadoDTO detalleCompleto = new HospitalizadoDTO();
            
            //Al tener el objeto creado le colocaremos los datos de la cita creada para despues mostrarlo al final
            detalleCompleto.setCodigo_hospitalizacion(hospitalizado.getCodigo_hospitalizacion());
            detalleCompleto.setSala(hospitalizado.getSala());;
            detalleCompleto.setHora_monitoreo(hospitalizado.getHora_monitoreo());;
            detalleCompleto.setDescripcion(hospitalizado.getDescripcion());;

            //Aqui usamos la comunicacion de microservicios , aqui con los metodos del client traemos la informacion desde los otros servicios
            MascotaDTO mascota = obtenerMascota(hospitalizado.getCodigo_microchip()).orElse(null);

            //Y aqui colocamos la informacion faltante en el detalle de la cita
            detalleCompleto.setMascotaDTO(mascota);
        
            //Y aqui al final devolvemos el detalle completo con toda la informacion que necesitemos
            return Optional.of(detalleCompleto);

        } catch (Exception e) {
            System.err.println("Error al armar el detalle completo de la Hospitalizacion: " + e.getMessage());
            throw new RuntimeException("Error interno al procesar el detalle de la Hospitalizacion");
        }
    }

}
