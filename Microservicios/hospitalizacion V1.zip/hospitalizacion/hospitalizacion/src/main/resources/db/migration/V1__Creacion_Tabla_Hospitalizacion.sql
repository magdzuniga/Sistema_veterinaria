CREATE TABLE hospitalizados(
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    codigo_hospitalizacion VARCHAR(255) NOT NULL UNIQUE,
    hora_monitoreo DATETIME NOT NULL,
    sala VARCHAR(100) NOT NULL,
    descripcion VARCHAR(255) NOT NULL,
    codigo_microchip BIGINT NOT NULL
    
);