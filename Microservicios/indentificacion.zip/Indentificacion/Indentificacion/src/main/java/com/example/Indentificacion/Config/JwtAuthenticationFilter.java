package com.example.Indentificacion.Config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.example.Indentificacion.Service.JwtService;

import java.io.IOException;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtService jwtService;
    // Este filtro es el encargado de interceptar cada petición que llega al backend,
    // revisar si tiene un Token JWT válido, y si es así, permitirle el acceso a las rutas protegidas.
    private final UserDetailsService userDetailsService;
    // Para cargar los detalles del usuario desde la base de datos, lo que nos permitirá validar el token y asignar los roles correspondientes.

    // Constructor para inyectar los servicios
    public JwtAuthenticationFilter(JwtService jwtService, UserDetailsService userDetailsService) {
        this.jwtService = jwtService;
        // Le inyectamos el JwtService para poder usarlo para validar los tokens, y el UserDetailsService para cargar los usuarios desde la base de datos.
        this.userDetailsService = userDetailsService;
        // Con esta inyección, este filtro tiene todo lo que necesita para revisar los tokens de las peticiones y decidir si le dan acceso al usuario o no.
    }

    @SuppressWarnings({ "deprecation", "null" })
    @Override
    protected void doFilterInternal(
            @Nullable HttpServletRequest request,
            // El método doFilterInternal es el que se ejecuta para cada petición que llega al backend. Aquí es donde vamos a revisar el token JWT.
            @NonNull HttpServletResponse response,
            // Recibimos la petición HTTP, la respuesta HTTP, y el filtro de la cadena de filtros de Spring Security.
            @NonNull FilterChain filterChain
            // El FilterChain es el que nos permite continuar con el proceso de la petición después de revisar el token. Si el token es válido, 
            // le damos acceso al usuario y luego llamamos a filterChain.doFilter para que la petición siga su camino hacia el controlador. 
            // Si el token no es válido, simplemente llamamos a filterChain.doFilter sin hacer nada, lo que hará que la petición llegue al 
            // siguiente filtro (que probablemente bloqueará el acceso si la ruta es protegida).

    ) throws ServletException, IOException {
        
        if (request.getServletPath().contains("/Inden")) {
            filterChain.doFilter(request, response);
            return;
        }

        

        final String authHeader = request.getHeader("Authorization");
        // Extraemos el encabezado "Authorization" de la petición, que es donde se espera que venga el token JWT en formato "Bearer <token>".
        final String jwt;
        // Declaramos una variable para guardar el token JWT que vamos a extraer del encabezado.
        final String userUsername;
        // Declaramos una variable para guardar el nombre de usuario que vamos a extraer del token JWT, si es válido.

        
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);
            // Si el encabezado no está presente o no tiene el formato correcto, simplemente continuamos con la cadena de filtros sin hacer nada, 
            // lo que hará que la petición llegue al siguiente filtro (que probablemente bloqueará el acceso si la ruta es protegida).
            return;
        }

        jwt = authHeader.substring(7);
        // Si el encabezado es correcto, extraemos el token JWT quitando la parte "Bearer " del inicio.
        
        
        userUsername = jwtService.extractUsername(jwt);
        // Usamos el JwtService para extraer el nombre de usuario del token JWT. Si el token es válido, 
        // este método nos devolverá el nombre de usuario que está guardado dentro del token.

       
        if (userUsername != null && SecurityContextHolder.getContext().getAuthentication() == null) {
            
            
            UserDetails userDetails = this.userDetailsService.loadUserByUsername(userUsername);
            // Si el nombre de usuario fue extraído correctamente del token, usamos el UserDetailsService para cargar los detalles de ese usuario desde la base de datos.

            
            if (jwtService.isTokenValid(jwt, userDetails)) {
                // Si el token JWT es válido para ese usuario (es decir, no ha expirado, fue firmado con nuestra clave secreta, y coincide con los datos del usuario),
                
                
                UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(
                    // Creamos un objeto de autenticación de Spring Security con los detalles del usuario, sin la contraseña (porque ya se validó con el token), y con sus roles.
                        userDetails,
                        // La contraseña no se incluye aquí porque el token ya ha sido validado, así que no necesitamos verificar la contraseña en este punto.
                        null,
                        // Los roles del usuario se incluyen para que Spring Security pueda manejar la autorización correctamente (por ejemplo, para permitir o denegar el acceso a ciertas rutas según el rol).
                        userDetails.getAuthorities() 
                        // El método getAuthorities() del UserDetails devuelve una colección de los roles o permisos que tiene el usuario, lo que Spring Security usará para manejar la autorización.
                );
                authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                // Aquí le damos más detalles a la autenticación, como la IP del usuario, el navegador que está usando, etc., lo que puede ser útil para auditorías o para detectar actividades sospechosas.
                
                SecurityContextHolder.getContext().setAuthentication(authToken);
                // Finalmente, le decimos a Spring Security que este usuario ya está autenticado para esta petición, y le asignamos el objeto de autenticación que creamos. 
                // Esto hará que, a partir de este punto, el sistema reconozca al usuario como autenticado y le permita acceder a las rutas protegidas según sus roles.
            }
        }
        
        filterChain.doFilter(request, response);
        // Continuamos con la cadena de filtros, lo que permitirá que la petición llegue a su destino (controlador) si el token es válido, o que sea bloqueada si no lo es.
    }
}