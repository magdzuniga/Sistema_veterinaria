package com.example.Indentificacion.Dto;

public class AuthenticationRequest {
    private String username;
    // Este DTO (Data Transfer Object) es una clase simple que se utiliza para recibir los datos de inicio de sesión (nombre de usuario y contraseña) 
    // desde el frontend cuando un usuario intenta iniciar sesión en la aplicación.
    private String password;
    // Tiene dos campos: username y password, que corresponden a los datos que el usuario ingresará en la pantalla de Login.

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    // Estos son los métodos getter y setter para el campo username, que permiten acceder y modificar el valor del nombre de usuario.

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    // Estos son los métodos getter y setter para el campo password, que permiten acceder y modificar el valor de la contraseña.
}