package com.example.Indentificacion.Dto;

public class AuthenticationResponse {
    private String token;
    // Este DTO (Data Transfer Object) es una clase simple que se utiliza para enviar la respuesta de autenticación (el Token JWT) 
    // desde el backend al frontend después de un registro o inicio de sesión exitoso.
    // Tiene un campo token, que es el Token JWT que el frontend debe guardar y enviar en el encabezado de las peticiones para acceder
    // a las rutas protegidas.

    public AuthenticationResponse(String token) {
        this.token = token;
    }
    // El constructor de esta clase recibe el token JWT como parámetro y lo asigna al campo token. 
    // Esto nos permite crear una instancia de AuthenticationResponse con el token que queremos enviar al frontend.

    public String getToken() { 
        return token; 
    }
    // El método getter para el campo token, que permite acceder al valor del token JWT que se va a enviar en la respuesta.

    public void setToken(String token) { 
        this.token = token;
    }
    // El método setter para el campo token, que permite modificar el valor del token JWT.
}