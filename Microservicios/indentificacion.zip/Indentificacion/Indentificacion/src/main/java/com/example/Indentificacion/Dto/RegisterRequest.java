package com.example.Indentificacion.Dto;

import com.example.Indentificacion.Model.Role; 

public class RegisterRequest {
    private String username;
    private String password;
    private Role role;

    public String getUsername() { 
        return username; 
    }
    // Este DTO (Data Transfer Object) es una clase simple que se utiliza para recibir los datos de registro (nombre de usuario, contraseña y rol) 
    // desde el frontend cuando un nuevo usuario intenta registrarse en la aplicación.

    public void setUsername(String username) { 
        this.username = username; 
    }
    // Tiene tres campos: username, password y role, que corresponden a los datos que el usuario ingresará en la pantalla de Registro.

    public String getPassword() { 
        return password; 
    }
    // Estos son los métodos getter y setter para el campo username, que permiten acceder y modificar el valor del nombre de usuario.   

    public void setPassword(String password) { 
        this.password = password; 
    }
    // Estos son los métodos getter y setter para el campo password, que permiten acceder y modificar el valor de la contraseña.

    public Role getRole() { 
        return role; 
    }
    // Estos son los métodos getter y setter para el campo role, que permiten acceder y modificar el valor del rol del usuario (ADMIN, VETERINARIO, etc.).
    
    public void setRole(Role role) { 
        this.role = role;
     }
    // Estos son los métodos getter y setter para el campo role, que permiten acceder y modificar el valor del rol del usuario (ADMIN, VETERINARIO, etc.).
}