package com.example.Indentificacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IndentificacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(IndentificacionApplication.class, args);
	}

}
