package com.example.Indentificacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IndentificacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(IndentificacionApplication.class, args);
		// Este es el punto de entrada principal de la aplicación Spring Boot. 
		// La anotación @SpringBootApplication indica que esta clase es la configuración principal de la aplicación 
		// y habilita la auto-configuración de Spring Boot. El método main() utiliza SpringApplication.run() para iniciar la aplicación, 
		// lo que a su vez inicia el servidor web integrado y carga el contexto de la aplicación.
	}

}
