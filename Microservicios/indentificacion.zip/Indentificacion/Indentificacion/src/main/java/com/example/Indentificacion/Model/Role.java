package com.example.Indentificacion.Model;

public enum Role {
//En lugar de decir class, dice enum. 
// Esto le avisa a Java que lo que viene dentro es una lista de constantes inmutables 
//(valores que se leen, pero no se modifican).
    ADMIN,
    VETERINARIO,
    RECEPCIONISTA
    //Estas son las únicas tres opciones válidas en todo tu sistema para definir el tipo de usuario.
    //Se escriben completamente en MAYÚSCULAS porque actúan como constantes.
}
