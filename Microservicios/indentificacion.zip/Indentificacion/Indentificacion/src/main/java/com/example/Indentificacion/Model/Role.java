package com.example.Indentificacion.Model;

public enum Role {
    ADMIN,
    VETERINARIO,
    RECEPCIONISTA
}
