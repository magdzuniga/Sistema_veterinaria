package com.example.Indentificacion.Model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;

@Getter
@Setter
/**
 * @Getter y @Setter son anotaciones de Lombok.
 * Generan automáticamente en segundo plano todos los métodos estructurados (get... y set...)
 * para cada variable privada, ahorrándonos escribir código repetitivo.
 */
@Entity 
//Le avisa a Framework (JPA) que esta clase representa una tabla en la base de datos.
@Table(name = "usuarios") 
//Le dice que, específicamente, la tabla en la base de datos se llamará usuarios (en plural), 
// aunque la clase se llame User.
//Al implementar esta interfaz de Spring Security, le estás diciendo al sistema de seguridad: 
// "Oye, usa esta clase para saber quién está intentando iniciar sesión y qué tiene permitido hacer".
public class User implements UserDetails { 
    @Id
    //Define que este campo será la Llave Primaria (Primary Key) de la tabla.
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    //Configura el ID para que sea autoincremental (1, 2, 3...). La base de datos se encargará de asignarlo automáticamente.

    @Column(unique = true, nullable = false)
    private String username; 
    //Configura restricciones para la columna en la base de datos. 
    // unique = true significa que no puede haber dos usuarios con el mismo nombre, 
    // y nullable = false obliga a que este campo nunca esté vacío.

    @Column(nullable = false)
    private String password;
    //Crea la columna para la contraseña, la cual tampoco puede ser nula (nullable = false). 
    //Por seguridad, aquí se guardará la contraseña ya encriptada.

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Role role; // ADMIN, VETERINARIO o RECEPCIONISTA
    //Indica que el rol (que viene de un ENUM llamado Role) se guardará en la base de datos como texto 
    //(por ejemplo, el texto "ADMIN"), en lugar de un número indexado (0, 1, 2).

    public User() {}
    //Es el constructor vacío. JPA/Hibernate lo necesita obligatoriamente para poder crear instancias de 
    //esta clase cuando recupera los datos desde la base de datos.

    
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority("ROLE_" + role.name()));
        //Convierte el rol de tu usuario en un formato que Spring Security entienda (GrantedAuthority). 
        //Por convención de Spring Security, se le concatena el prefijo "ROLE_". 
        //Si el rol es ADMIN, Spring Security verá que tiene el permiso ROLE_ADMIN.
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getUsername() {
        return username;
    }
    //Le devuelven a Spring Security las credenciales exactas (usuario y contraseña) para que pueda validar el formulario de Login.

    // Los siguientes 4 métodos le dicen a Spring Security que la cuenta está activa
    @Override
    public boolean isAccountNonExpired() {
        return true; 
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
    //Estos cuatro métodos manejan los estados de la cuenta. Al retornar true en todos, estás configurando por defecto que:
    // La cuenta no ha expirado.
    // El usuario no está bloqueado.
    // Las contraseñas no han caducado.
    // El usuario está activo/habilitado para entrar al sistema de inmediato.
}