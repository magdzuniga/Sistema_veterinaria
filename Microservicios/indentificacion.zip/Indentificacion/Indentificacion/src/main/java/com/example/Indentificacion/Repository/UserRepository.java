package com.example.Indentificacion.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Indentificacion.Model.User;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    
    // Este método mágico le permite a Spring Security buscar al usuario en Laragon para el Login
    Optional<User> findByUsername(String username);
}