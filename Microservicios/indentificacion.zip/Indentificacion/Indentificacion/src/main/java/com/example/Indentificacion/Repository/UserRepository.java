package com.example.Indentificacion.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Indentificacion.Model.User;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    
    Optional<User> findByUsername(String username);
}

//El encargado de ir a buscar al usuario a la base de datos cuando este intenta iniciar sesión en la pantalla de Login, 
// asegurándose de que exista antes de pedirle la contraseña.