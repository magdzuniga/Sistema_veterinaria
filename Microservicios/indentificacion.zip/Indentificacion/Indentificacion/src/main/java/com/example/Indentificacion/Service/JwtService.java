package com.example.Indentificacion.Service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;  
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;   

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

@Service
public class JwtService {

    @Value("${jwt.secret}")
    //Le dice a Spring Boot no escribas estos datos directamente aquí por seguridad;
    // ve a buscarlos a nuestro archivo application.properties, donde los tenemos guardados en base64.
    private String secretKey;
    // Lee la llave secreta (en base64) que usaremos para guardar nuestros Tokens JWT de forma segura, }
    // y para verificar que los tokens que recibimos en las peticiones realmente fueron emitidos por nuestro sistema 
    // y no por un impostor.


    @Value("${jwt.expiration}")
    //Es el tiempo de vida en nuestro caso lo configure para 24 horas. 
    // Pasado ese tiempo, se borra automaticamente y el usuario debe loguearse otra vez. 
    private long jwtExpiration;
    // Lee el tiempo de expiración que le queremos dar a nuestros Tokens JWT,
    // para que no sean eternos y obligar a los usuarios a iniciar sesión de nuevo después de un tiempo, por seguridad.

    // ==========================================
    // 1. EXTRAER DATOS DEL TOKEN (Para saber quién es)
    // ==========================================

    public String extractUsername(String token) {
        return extractClaim(token, Claims::getSubject);
        // El "subject" (sujeto) de un token JWT es el dato principal que se guarda dentro de él,
        // y normalmente se usa para guardar el nombre de usuario (username) del usuario al que pertenece ese token.
    }

    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        // Este método es súper flexible porque le puedes pasar cualquier función que tome los "claims" (datos) del token 
        // y te devuelva lo que quieras.
        return claimsResolver.apply(claims);
        // Por ejemplo, si quieres extraer el rol del usuario, podrías llamar a este método con una función que busque el claim 
        // específico donde guardaste el rol.
    }

   
    // ==========================================
    // 2. CREAR EL TOKEN (Para el Login)
    // ==========================================

    public String generateToken(UserDetails userDetails) {
        return generateToken(new HashMap<>(), userDetails);
        // Este método es el que se llama desde el servicio de autenticación (AuthService) cada vez que un usuario se registra o inicia sesión.
        // Le pasamos el UserDetails del usuario que acaba de autenticarse, y el sistema le fabrica un Token JWT personalizado para él,
        // que contiene su nombre de usuario y su rol, para que pueda usarlo en sus próximas peticiones sin tener que volver a escribir su contraseña.
    }

    public String generateToken(Map<String, Object> extraClaims, UserDetails userDetails) {
        return Jwts.builder()
                .setClaims(extraClaims)
                // Aquí puedes agregar cualquier información extra que quieras guardar dentro del token, como el rol del usuario, su ID, etc.
                .setSubject(userDetails.getUsername()) 
                // El "subject" (sujeto) del token es el dato principal que se guarda dentro de él, y normalmente se usa para guardar el nombre de usuario (username).
                .setIssuedAt(new Date(System.currentTimeMillis())) 
                // Fecha de emisión del token (cuando se creó).
                .setExpiration(new Date(System.currentTimeMillis() + jwtExpiration)) 
                // Fecha de expiración del token (cuando se borra automáticamente). 
                // Se calcula sumando el tiempo de expiración que definimos a la fecha actual.
                .signWith(getSignInKey(), SignatureAlgorithm.HS256) 
                // Aquí es donde se firma el token con nuestra llave secreta usando el algoritmo HS256, para que el sistema pueda verificar su autenticidad cada vez que lo reciba.
                .compact();
                // Finalmente, se construye el token y se devuelve como una cadena de texto que el usuario puede usar para autenticarse en sus próximas peticiones.
    }
    
    // ==========================================
    // 3. VALIDAR EL TOKEN (El guardia de seguridad)
    // ==========================================

    public boolean isTokenValid(String token, UserDetails userDetails) {
        final String username = extractUsername(token);
        // Para que un token sea válido, el nombre de usuario que contiene debe coincidir con el del UserDetails que le pasamos,
        // y además el token no debe haber expirado.
        return (username.equals(userDetails.getUsername())) && !isTokenExpired(token);
        // Si el token es inválido o ya caducó, el sistema le negará el acceso a los datos y le pedirá que inicie sesión de nuevo 
        // para obtener un nuevo token.
    }

    private boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
        // Este método revisa si la fecha de expiración del token ya pasó en comparación con la fecha actual.
    }

    private Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
        // Extrae la fecha de expiración del token usando el método flexible de extractClaim.
    }
    
    // ==========================================
    // MÉTODO AUXILIAR: Obtener la llave criptográfica
    // ==========================================
    
    private Claims extractAllClaims(String token) {
        return Jwts.parserBuilder()
        // Para leer los datos de un token JWT, el sistema necesita verificar su firma con la misma llave secreta que se usó para crearlo.
                .setSigningKey(getSignInKey())
                // Si la firma es correcta, el sistema puede confiar en los datos que contiene el token y extraerlos para usarlos en la aplicación.
                .build()
                // Si la firma no es correcta (por ejemplo, si alguien intentó modificar el token o usar uno falso), el sistema lanzará un error 
                // y no permitirá el acceso a los datos.
                .parseClaimsJws(token)
                // Finalmente, si todo es correcto, se devuelve el cuerpo del token (los "claims") que contiene la información del usuario.
                .getBody();
                // Este método es el que se llama cada vez que queremos extraer información de un token, como el nombre de usuario o la fecha de expiración.
    }

    private Key getSignInKey() {
        // Para crear la llave criptográfica a partir de la cadena secreta en base64, primero la decodificamos 
        // y luego la convertimos en una Key que el sistema pueda usar para firmar y verificar los tokens.
        byte[] keyBytes = Decoders.BASE64.decode(secretKey);
        // La clase Keys de la biblioteca jjwt nos ayuda a crear una Key segura a partir de los bytes decodificados de nuestra cadena secreta.
        return Keys.hmacShaKeyFor(keyBytes);
        // Esta Key es la que se usará tanto para firmar los tokens cuando se crean, como para verificar su firma cada vez que se reciben en las peticiones.
    }
    
}
