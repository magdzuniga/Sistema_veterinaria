CREATE TABLE usuarios (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    firstname VARCHAR(100) NOT NULL,
    lastname VARCHAR(100) NOT NULL, 
    email VARCHAR(100) UNIQUE NOT NULL, -- El correo electrónico debe ser único para cada usuario
    password VARCHAR(255) NOT NULL, -- 255 porque la contraseña encriptada por BCrypt es larga
    role VARCHAR(50) NOT NULL       -- Aquí se guardará ADMIN, VETERINARIO, etc.
);