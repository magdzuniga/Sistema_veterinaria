package com.example.Indentificacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IndentificacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
