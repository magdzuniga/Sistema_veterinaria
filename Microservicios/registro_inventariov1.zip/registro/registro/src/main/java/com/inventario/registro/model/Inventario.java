package com.inventario.registro.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "inventario")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Inventario {
    
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private long id;
    
    @Column(unique = true,nullable =  false)
    private String nombre;
    
    @Column(nullable =  false)
    private LocalDate fecha_elaboracion;
    
    @Column(nullable =  false)
    private String vencimiento;
    
    @Column(nullable =  false)
    private long stock;
    
    @Column(nullable =  false)
    private String descripcion;

}
